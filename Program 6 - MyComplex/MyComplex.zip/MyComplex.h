#pragma once
class MyComplex
{
	public:
		MyComplex();
		MyComplex(float rp, float ip);

		float getIPart(); void setIPart(float rp);
		float getRPart(); void setRPart(float ip);

		void printMyComplex();
		MyComplex operator * (const MyComplex& param);
		MyComplex operator + (const MyComplex& param);
		MyComplex operator - (const MyComplex& param);

	private:
		float realPart;
		float iPart;
};

