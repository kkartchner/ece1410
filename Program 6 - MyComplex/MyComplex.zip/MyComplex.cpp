#include "MyComplex.h"
#include <iostream>

/***********************************Constructors****************************************/
MyComplex::MyComplex() { realPart = 0;	iPart = 0; }
MyComplex::MyComplex(float rp, float ip) {	realPart = rp;	iPart = ip; }

/*********************************Get/Set Functions*************************************/
float MyComplex::getRPart() { return realPart; }
void MyComplex::setRPart(float rp) { realPart = rp; }

float MyComplex::getIPart() { return iPart; }
void MyComplex::setIPart(float ip) { iPart = ip; }

/***************************Remaining Function Definitions******************************/

/****************************************************************************************
* Function Title: printMyComplex
*
* Summary: Prints realPart and iPart in complex number form.
*
* Inputs: none
* Output: none
*****************************************************************************************/
void MyComplex::printMyComplex()
{
	std::cout << realPart << " + " << iPart << "i";
}

/****************************************************************************************
* Function Title: operator+ 
*	
* Summary: Overides the '+' operator to add real part and imaginary part seperate when 
* dealing with objects of MyComplex.
*
* Inputs: param (the MyComplex on right side of '+' passed in by reference)
* Outputs: temp (sum of the MyComplex numbers)
*****************************************************************************************/
MyComplex MyComplex::operator+ (const MyComplex& param)						// Pseudocode
{																			// Begin
	MyComplex temp;															//		Declare temp as MyComplex
	temp.realPart = realPart + param.realPart;								//		Set temp real part to equal the sum of the real parts
	temp.iPart = iPart + param.iPart;										//		Set temp imaginary part to equal the sum of the imaginary parts
	return temp;															//		Return temp
}																			// End
																			
/****************************************************************************************
* Function Title: operator-  
* 
* Summary: Overrides the '-' operator to subtract real part and imaginary part seperate when 
* dealing with objects of MyComplex.
*
* Inputs: param (the MyComplex on right side of '-' passed in by reference)
* Outputs: temp (difference of the MyComplex numbers)
*****************************************************************************************/
MyComplex MyComplex::operator- (const MyComplex& param)						// Pseudocode
{																			// Begin
	MyComplex temp;															//		Declare temp as MyComplex
	temp.realPart = realPart - param.realPart;								//		Set temp real part to equal the difference of the real parts
	temp.iPart = iPart - param.iPart;										//		Set temp imaginary part to equal the difference of the imaginary parts
	return temp;															//		Return temp
}																			// End

/****************************************************************************************
* Function Title: operator*  
* 
* Summary: Overrides the '*' operator to multiply two objects of MyComplex using the FOIL
* method to calculate the real and imaginary parts.
*
* Inputs: param (the MyComplex on right side of '*' passed in by reference)
* Outputs: temp (product of the MyComplex numbers)
*****************************************************************************************/
MyComplex MyComplex::operator* (const MyComplex& param)						// Pseudocode
{																			// Begin
	MyComplex temp;															//		Declare temp as MyComplex
																			//		Set temp by using the FOIL method, and keeping in mind that i is the square root of -1
	temp.realPart = (realPart * param.realPart) - (iPart * param.iPart);	//		temp real part equals product of first terms minus product of last terms
	temp.iPart = (realPart * param.iPart) + (iPart * param.realPart);		//		temp imaginary part equals product of inner terms plus product of outer terms
	return temp;															//		Return temp
}																			// End





