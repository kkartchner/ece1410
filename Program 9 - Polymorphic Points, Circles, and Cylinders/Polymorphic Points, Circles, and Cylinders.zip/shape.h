#ifndef SHAPE_H
#define SHAPE_H
#include <ostream>
class Shape
{
	public: 
		virtual void printShape(std::ostream& os) =0;
	
	friend std::ostream& operator<< (std::ostream& os, Shape& c) { c.printShape(os); return os; }
};
#endif


