#ifndef POINT_H
#define POINT_H
#include "shape.h"

class Point : public Shape
{
	protected:
		int x, y;
	public:
		Point();
		Point(int x, int y);
		void printShape(std::ostream & os);
};
#endif