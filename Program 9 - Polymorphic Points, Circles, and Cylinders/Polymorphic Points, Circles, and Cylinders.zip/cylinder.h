#ifndef CYLINDER_H
#define CYLINDER_H
#include "circle.h"

class Cylinder : public Circle
{
	protected:
		int height;
		double volume;
	public:
		Cylinder();
		Cylinder(int posX, int posY, int radius, int height);
		void printShape(std::ostream & os);
};
#endif

