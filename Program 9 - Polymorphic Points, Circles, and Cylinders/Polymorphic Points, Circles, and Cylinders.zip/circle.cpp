#include "circle.h"
#define PI 3.14159

Circle::Circle() : Point() { radius = 0; area = 0; }				// Default constructor; set radius and area to 0

Circle::Circle (int posX, int posY, int r) : Point(posX, posY)      // Constructor (int, int, int) : pass in posX and posY to Point (int, int) base constructor
{
	radius = r;														// Set radius to provided r parameter
	area = PI * r * r;												// Area of a circle is PI times the radius squared
}

void Circle::printShape (std::ostream& os)							// Override the printShape base function for printing
{
	os << "Circle with center = (" << x << ", " << y << "); Radius = " << radius << "; Area = " << area;	// Message to print when << (Circle) is called
}