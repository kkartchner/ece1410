#include "cylinder.h"

Cylinder::Cylinder() : Circle() { height = 0; volume = 0; }						// Default constructor; set height and volume to 0

Cylinder::Cylinder(int posX, int posY, int r, int h) : Circle(posX, posY, r)	// Constructor (int, int, int, int) : pass in posX, posY, and r to Circle (int, int, int) base constructor
{
	height = h;																	// Set height to provided h parameter
	volume = area * height;														// Volume of a cylinder equals the base area times the height
}

void Cylinder::printShape(std::ostream& os)										// Override the printShape base function for printing
{
	os << "Cylinder with center = (" << x << ", " << y << "); Radius = " << radius << "; Height = " << height << "; Volume = " << volume;		// Message to print when << (Cylinder) is called
}
