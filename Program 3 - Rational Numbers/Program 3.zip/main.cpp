#include "rational.h"

using namespace std;
/**********************************************************************************************
* Function Title: main
*
* Summary: Prompts the user to enter an initial fraction numerator and denominator, then enters
* a loop that displays a menu for performing operations on the fraction that was entered
*
* Inputs: none
* Outputs: none
***********************************************************************************************
* Pseudocode
*
* Begin
*		Declare variables to be used
* 		Print program instructions
* 		Prompt user and get a fraction
* 		Loop
* 			Print list of rational operation codes
* 			Prompt user to enter a code
* 			Try
* 				Get the code and throw its value
* 			Catch the value
* 				Perform an action or print an error based which code was entered
* 			End Try
* 		End Loop
* End
***********************************************************************************************/
int main()
{																		//	Begin
	Rational rtn;														//		Declare variables to be used
	int select = 0, n, d;	bool exit = false;
	
	cout << "Welcome to Frac-Calc!" << endl;							//		Print program instructions
	rtn.get_fraction();													//		Prompt user and get a fraction
	while (!exit) {														//		Loop
		cout << endl << "What would you like to do?" << endl;			//			Print list of rational operation codes
		cout << "1. Add a rational" << endl;				
		cout << "2. Subtract a rational" << endl;
		cout << "3. Multiply by a rational" << endl;
		cout << "4. Divide by a rational" << endl;
		cout << "0: Exit" << endl;
		cout << "Enter selection: ";									//			Prompt user to enter a code
		try {															//			Try
			cin >> select; throw select;								//				Get the code and throw its value
		} catch (int e){												//			Catch the value
			switch (e) {												//				Perform an action or print an error based which code was entered
			case 0: exit = true; break;									
			case 1: rtn.get_fraction(&n, &d);
				rtn.add(n, d);	break;
			case 2: rtn.get_fraction(&n, &d);
				rtn.sub(n, d);	break;
			case 3: rtn.get_fraction(&n, &d);
				rtn.mul(n, d);	break;
			case 4: rtn.get_fraction(&n, &d);
				rtn.div(n, d);	break;
			default:
				cout << endl << "Invalid code. Enter one of the codes below: " << endl;
				break;
			}
		}																//			End Try
	}																	//		End Loop
	return 0;
}																		//	End