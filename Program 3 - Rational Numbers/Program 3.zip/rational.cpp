#include "rational.h"
#include <math.h>

using namespace std;
/**********************************************************************************************
* Function Title: add
*
* Summary: Adds the fraction (n/d), to the stored fraction using cross-multiplication, prints the
* result, then reduces the fraction if possible by calling the "reduce" function
*
* Inputs: n, d (ints; numerator and denominator of fraction to add to stored fraction)
* Outputs: none
***********************************************************************************************/
void Rational::add(int n, int d) {																	// Begin
	cout << numerator << "/" << denominator << " plus " << n << "/" << d << " is:  ";				//		Print first part of result message

	if (denominator == d) {																			//		If the fractions have the same denominator
		numerator += n;																				//			Add numerators straight across
	} else {																						//		Else											
		numerator = (numerator * d) + (n * denominator);											//			Add using cross multiplication to get common denominator
		denominator = (denominator * d);
	}																								//		End If
																									
	cout << numerator << "/" << denominator << endl;												//		Print remainder of result message								
	reduce(&numerator, &denominator);																//		Reduce resulting fraction if possible																
}																									// End

/**********************************************************************************************
* Function Title: sub
*
* Summary: Subtracts the fraction (n/d) from the stored fraction by using cross-multiplication, 
* prints the result, then reduces the fraction if possible by calling the "reduce" function
*
* Inputs: n, d (ints; numerator and denominator of fraction to subtract from the stored fraction)
* Outputs: none
***********************************************************************************************/
void Rational::sub(int n, int d) {																	// Begin
	cout << numerator << "/" << denominator << " minus " << n << "/" << d << " is:  ";				//		Print first part of result message

	if (denominator == d) {																			//		If the fractions have the same denominator
		numerator -= n;																				//			Subtract numerators straight across
	} else {																						//		Else
		numerator = (numerator * d) - (n * denominator);											//			Subtract using cross multiplication to get common denominator
		denominator = (denominator * d);															//		End If
	}

	cout << numerator << "/" << denominator << endl;												//		Print remainder of result message																							
	reduce(&numerator, &denominator);																//		Reduce resulting fraction if possible
}																									// End

/**********************************************************************************************
* Function Title: mul
*
* Summary: Multiplies the stored fraction by the fraction (n/d), prints the result, 
* then reduces the fraction if possible by calling the "reduce" function
*
* Inputs: n, d (ints; numerator and denominator of fraction to multiply the stored fraction by)
* Outputs: none
***********************************************************************************************/
void Rational::mul(int n, int d) {																	// Begin
	cout << numerator << "/" << denominator << " times " << n << "/" << d << " is:  ";				//		Print first part of result message

	numerator *= n;	denominator *= d;																//		Multiply numerators and denominators

	cout << numerator << "/" << denominator << endl;												//		Print remainder of result message
	reduce(&numerator, &denominator);																//		Reduce resulting fraction if possible
}																									// End

/**********************************************************************************************
* Function Title: div
*
* Summary: Divides the stored fraction by the fraction (n/d) by multiplying by the reciprocal,
* prints the result, then reduces the fraction if possible by calling the "reduce" function
*
* Inputs: n, d (ints; numerator and denominator of fraction to divide the stored fraction by)
* Outputs: none
***********************************************************************************************/
void Rational::div(int n, int d) {																	// Begin
	cout << numerator << "/" << denominator << " divided by " << n << "/" << d << " is:  ";			//		Print first part of result message

	numerator *= d;	denominator *= n;																//		Times by the reciprocal

	cout << numerator << "/" << denominator << endl;												//		Print remainder of result message
	reduce(&numerator, &denominator);																//		Reduce resulting fraction if possible
}																									// End

/**********************************************************************************************
* Function Title: reduce
*
* Summary: Finds the greatest common factor between the numerator and denominator, divides
* them both by it to reduce the fraction as much as possible, then prints the result if reduced.
*
* Inputs: n, d (int pointers to the numerator and denominator variables to be modified)
* Outputs: none
***********************************************************************************************/
void Rational::reduce(int *n, int *d) {									// Begin									
	int i; bool reduced = false;										//		Declare variables to be used
	i = (abs(*n) < abs(*d)) ? abs(*n) : abs(*d);						//		Set i to equal the absolute value of n or of d, whichever value is smaller			
	
	for (; i > 1 && !reduced; i--) {									//		Loop while i > 1 and reduced is false
		if ((*n % i == 0) && (*d % i == 0)) {							//			If the GCF has been found
			reduced = true;												//				Set reduced to true									
			*n /= i; *d /= i;											//				Divide the numerator and denominator by the GCF
			if (*d == 1 || *n == 0) {									//				If the denominator = 1 or the numerator = 0
				cout << "Reduces to:  " << *n << endl;					//					Print message with only the numerator
			} else {													//				Else
				cout << "Reduces to:  " << *n << "/" << *d << endl;		//					Print message with the numerator / denominator
			}															//				End If
		}																//			End If
	}																	//		End Loop
}																		// End


/**********************************************************************************************
* Function Title: get_fraction
*
* Summary: Prompts the user to enter a numerator and a denominator, retrieves the values (and
* makes sure they are valid), and prints it in fraction form
*
* Inputs: n, d (int pointers to the numerator and denominator variables to be modified)
* Outputs: none
***********************************************************************************************/
void Rational::get_fraction(int *n, int *d){							// Begin
	bool successful = false;											//		Declare variables to be used
	cout << endl << "Enter fraction numerator: "; 						//		Print "Enter numerator: " message
	cin >> *n;															//		Get numerator

	while (!successful) {												//		Loop while a valid denominator has not been entered
		cout << "Enter the denominator: ";								//			Print "enter denominator" message
		try {															//			Try
			cin >> *d; throw *d;										//				Get denominator and throw its value
		} catch (int e) {												//			Catch the value
			if (e == 0) {												//				If the value is 0
				cout << "Denominator cannot be 0" << endl;				//					Print error message
			} else {													//				Else	
				successful = true;										//					A valid denominator has been entered
			}															//				End If
		}																//			End Try
	}																	//		End Loop
	cout << "You entered:  " << *n << "/" << *d << endl;				//		Print "You entered: " followed by the fraction entered
	reduce(n, d);														//		Reduce the fraction if possible by calling the "reduce" function
}																		// End

/**********************************************************************************************
* Function Title: get_fraction
*
* Summary: Calls the get_fraction (int, int) function, passing in local class numerator and
* denominator variables as arguments
* 
* Inputs: none
* Outputs: none
***********************************************************************************************/
void Rational::get_fraction(void){										
	get_fraction(&numerator, &denominator);								
}																		