#ifndef RATIONAL_H
#define RATIONAL_H
#include <iostream>

class Rational
{
private:
	int numerator, denominator;
public:
	void add(int n, int d);
	void sub(int n, int d);
	void mul(int n, int d);
	void div(int n, int d);
	void reduce(int *n, int *d);
	void get_fraction(int *n, int *d);
	void get_fraction(void);
};
#endif