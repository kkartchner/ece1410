#ifndef MYSTACK_H
#define MYSTACK_H

template <class T>
class MyStack
{
	private:								// Private members to be used
		T stack[10];
		int top;
		void throwException(int e);
	public:
		MyStack() { clear(); }				// Clear stack upon object instantiation

		void clear() { top = 0; }			// "Clears" the stack by setting top to 0

		bool full() { return top == 10; }	// Returns true if the stack is full (top equals 10); false if not
		bool empty() { return top == 0; }	// Returns true if the stack is empty (top equals 0); false if not

		int size() { return top; }			// Returns the size of the stack by returning "top"

		T peek() { if (!empty()) return stack[top - 1]; else throwException(0); return 0; }				// Returns the top object of the stack if the stack isn't empty, otherwise throws exception 0
		T pop() { if (!empty()) return stack[top--]; else throwException(1); return 0; }				// Returns the top object and removes it from the stack if the stack isn't empty, otherwise throws exception 1
		void push(T param) { if (!full()) { stack[top] = param; top++; } else throwException(2); };		// Puts param onto the top of the stack if the stack isn't full, otherwise throws exception 2
};

template <class T>
void MyStack<T>::throwException(int e) {	// Throws the equivalent exception of the number passed in
	try { throw e; }
	catch (int e) {
		switch (e) {
			case 0: std::cout << "Exception: Tried to peek at an empty stack!" << std::endl; break;	
			case 1: std::cout << "Exception: Tried to pop from an empty stack!" << std::endl; break;
			case 2: std::cout << "Exception: Tried to push to a full stack!" << std::endl; break;
		}
	}
}
#endif
