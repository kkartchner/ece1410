#ifndef MYQUEUE_H
#define MYQUEUE_H

template <class T>
class MyQueue
{
	private:																// Private members to be used
		T queue[10];
		int head, tail, qsize;
		void throwException(int e);
		void increment(int *index) { *index = (*index + 10 - 1) % 10; };	// Increment provided index circularly (if end of array is reached it loops back around to the beginning)
	public:
		MyQueue() { clear(); }												// Clear queue upon object instantiation
	
		void clear() { head = tail = qsize = 0; }							// "Clears" the queue by setting head, tail, and qsize to 0
	
		bool full() { return qsize == 10; }									// Returns true if the queue is full ( ); false if not
		bool empty() { return qsize == 0; }									// Returns true if the queue is empty ( ); false if not
	
		int size() { return qsize; }										// Returns the size of the queue by returning qsize
	
		T peek() { if (!empty()) return queue[tail]; else throwException(0); return 0; }			 // Returns the tail object of the queue if the queue isn't empty, otherwise throws exception 0 and returns 0
		T pop() {																					 // Returns the tail object and removes it from the queue if the queue isn't empty, otherwise throws exception 1 and returns 0
			if (!empty()) { int temp = tail; increment(&tail); qsize--; return queue[temp];	} else 	throwException(1); return 0;
		}			
		void push(T param) {																		 // Puts param onto the queue circularly if the queue isn't full, otherwise throws exception 2
			if (!full()) { queue[head] = param; increment(&head); qsize++; } else throwException(2);
		}
};

template <class T>
void MyQueue<T>::throwException(int e) {									// Throws the equivalent exception of the number passed in
	try { throw e; }
	catch (int e) {
		switch (e) {
			case 0: std::cout << "Exception: Tried to peek at an empty queue!" << std::endl; break;
			case 1: std::cout << "Exception: Tried to pop from an empty queue!" << std::endl; break;
			case 2: std::cout << "Exception: Tried to push to a full queue!" << std::endl; break;
		}
	}
}
#endif
