#include "Point.h"
#include <string>

Point::Point() { x = 0; y = 0; }				// Default constructor; set x and y to 0

Point::Point(int posX, int posY)				// Contructor (int, int)
{
	x = posX; y = posY;							// Set x and y to provided parameter values
}

std::ostream& operator<<(std::ostream& os, const Point& p)			// Override the insertion (<<) operator for printing
{
	os << "Point at (" << p.x << ", " << p.y << ")";				// Message to print when << (Point) is called
	return os;
}
