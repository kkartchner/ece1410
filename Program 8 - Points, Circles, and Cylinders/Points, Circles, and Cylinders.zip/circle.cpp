#include "circle.h"
#define PI 3.14159

Circle::Circle() : Point() { radius = 0; area = 0; }				// Default constructor; set radius and area to 0

Circle::Circle (int posX, int posY, int r) : Point(posX, posY)      // Constructor (int, int, int) : pass in posX and posY to Point (int, int) base constructor
{
	radius = r;														// Set radius to provided r parameter
	area = PI * r * r;												// Area of a circle is PI times the radius squared
}

std::ostream& operator<<(std::ostream& os, const Circle& c)															// Override the insertion (<<) operator for printing
{
	os << "Circle with center = (" << c.x << ", " << c.y << "); Radius = " << c.radius << "; Area = " << c.area;	// Message to print when << (Circle) is called
	return os;
}