#ifndef POINT_H
#define POINT_H
#include <ostream>

class Point
{
protected:
	int x, y;
public:
	Point();
	Point(int x, int y);

	friend std::ostream& operator <<(std::ostream& os, const Point& p);
};
#endif