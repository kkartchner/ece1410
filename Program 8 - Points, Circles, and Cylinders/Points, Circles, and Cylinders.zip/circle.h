#ifndef CIRCLE_H
#define CIRCLE_H
#include "point.h"

class Circle : public Point
{
protected:
	int radius;
	double area;
public:
	Circle();
	Circle(int posX, int posY, int r);

	friend std::ostream& operator<<(std::ostream& os, const Circle& c);
};
#endif 