#include "cylinder.h"

Cylinder::Cylinder() : Circle() { height = 0; volume = 0; }						// Default constructor; set height and volume to 0

Cylinder::Cylinder(int posX, int posY, int r, int h) : Circle(posX, posY, r)	// Constructor (int, int, int, int) : pass in posX, posY, and r to Circle (int, int, int) base constructor
{
	height = h;																	// Set height to provided h parameter
	volume = area * height;														// Volume of a cylinder equals the base area times the height
}

std::ostream& operator<<(std::ostream& os, const Cylinder& c)					// Override the insertion (<<) operator for printing
{
	os << "Cylinder with center = (" << c.x << ", " << c.y << "); Radius = " << c.radius << "; Height = " << c.height << "; Volume = " << c.volume;		// Message to print when << (Cylinder) is called
	return os;
}
