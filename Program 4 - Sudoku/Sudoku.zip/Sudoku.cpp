#include "Sudoku.h"
#include <iostream> 
#include <ctime>
#include <cstdlib>

using namespace std;
/*************************************************************************************
* Function Title: Sudoku
*
* Summary: Randomly (but legally) populates the grid array with the number of squares 
* specified by the user, then prints the grid.

* Inputs: none
* Outputs:	none
**************************************************************************************/															
Sudoku::Sudoku(int popNum)											// Pseudocode
{																	// Begin
	int x, y, val, i = 0;											//		Declare variables to be used
	std::srand((unsigned) time(NULL));								//		Seed random number with time

	initializeGrid();												//		Initialize the grid

	while (i < popNum){												//		Loop (while i < popNum)
		x = rand() % 8; y = rand() % 8; val = 1 + rand() % 8;		//			Set x, y, and val to random numbers
		if (grid[x][y] == 0) {										//			If the value at grid[x][y] is 0
			if (isLegal(val, x, y)) {								//				If there are no violations
				grid[x][y] = val; 									//					Set the value at grid[x][y] to val
				fixed[x][y] = 1; i++;								//					Set the value at fixed[x][y] to val, then increment i
			}														//				End If
		}															//			End If
	}																//		End Loop
	printGrid();													//		Print the grid to the console
}																	// End

/*************************************************************************************
* Function Title: Sudoku
*
* Summary: Randomly (but legally) populates the grid array with the number of squares 
* specified by the user, then prints the grid.

* Inputs: none
* Outputs:	none
**************************************************************************************/		
void Sudoku::printGrid()																// Psuedocode
{																						// Begin
	for (int x = 0; x < 9; x++) {														//	 	Loop 9 times (using "x" for incrementing)
		if (x % 3 == 0 && x !=0) {														// 			Separate columns into thirds
			cout << "---------------------"<< endl;
		}
		for (int y = 0; y < 9; y++) {													//			Loop 9 times (using "y" for incrementing)
			if (y % 3 == 0 && y != 0) {													//			Separate rows into thirds
				cout << "| ";
			}
			if (grid[x][y] != 0) {														//				If the value at grid[x][y] is not 0
				cout << grid[x][y] << " ";												//					Print value of grid[x][y] to console
			} else {																	//				Else
				cout << "*" << " ";														//					Print a hyphen to console
			}																			//				End If
		}																				//			End Loop
		cout << endl;																	//			Print a new line after each row
	}																					//	 	End Loop
	cout << endl;																		//		Print a new line after the grid
}																						// End

/*************************************************************************************
* Function Title: Sudoku
*
* Summary: Randomly (but legally) populates the grid array with the number of squares 
* specified by the user, then prints the grid.

* Inputs: none
* Outputs:	none
**************************************************************************************/		
void Sudoku::initializeGrid()															// Psuedocode
{																						// Begin
	for (int x = 0; x < 9; x++) {														//		Loop 9 times (using "x" for incrementing)
		for (int y = 0; y < 9; y++) {													//			Loop 9 times (using "y" for incrementing)
			grid[x][y] = 0;																//				Set grid[x][y] to 0
			fixed[x][y] = 0;															//				Set fixed[x][y] to 0
		}																				//			End Loop
	}																					//		End Loop
}																						//	End

/*************************************************************************************
* Function Title: InRow
*
* Summary: Checks to see if the provided row contains the provided value.

* Inputs: val (value to check), y (position of column)
* Outputs:	true (if column contains val), or false (if it does not)
**************************************************************************************/
bool Sudoku::inRow(int val, int y)														// Psuedocode
{																						// Begin
	for (int x = 0; x < 9; x++) {														//		 Loop through the column (using x for incrementing)
		if (grid[x][y] == val) {														//			If the value at grid[x][y] equals val
			return true;																//				Return true
		}																				//			End If
	}																					//		 End Loop
	return false;																		//		 Default return of false if val is not found
}																						// End


/*************************************************************************************
* Function Title: InCol
*
* Summary: Checks to see if the provided column contains the provided value.

* Inputs: val (value to check), x (position of column)
* Outputs:	true (if column contains val), or false (if it does not)
**************************************************************************************/
bool Sudoku::inCol(int val, int x)														// Psuedocode
{																						// Begin
	for (int y = 0; y < 9; y++) {														//		 Loop through the column (using y for incrementing)
		if (grid[x][y] == val) {														//			If the value at grid[x][y] equals val
			return true;																//				Return true
		}																				//			End If
	}																					//		 End Loop
	return false;																		//		 Default return of false if val is not found
}																						// End

/*************************************************************************************
* Function Title: InBox
*
* Summary: Checks to see if the 3 by 3 box that contains position (x, y) already contains
* the value stored in val
*.
* Inputs: val (the value to check), x (position x to check), y (position y to check)
* Outputs:	true (if box contains val) or false (if it does not)
**************************************************************************************/
bool Sudoku::inBox(int val, int x, int y)												// Psuedocode
{																						// Begin
	int startX = 0, startY = 0, endX = 0, endY = 0;
	switch (x) {																		//		 Determine which x-quadrant x is in and set startX to beginning of quadrant
		case 0: case 1:	case 2: startX = 0; endX = 3; break;							
		case 3: case 4:	case 5: startX = 3; endX = 6; break;
		case 6: case 7:	case 8: startX = 6; endX = 9; break;
	}
	switch (y) {																		//		 Determine which y-quadrant y is in and set startX to beginning of quadrant
		case 0: case 1:	case 2: startY = 0; endY = 3; break;
		case 3: case 4:	case 5: startY = 3; endY = 6; break;
		case 6: case 7:	case 8: startY = 6; endY = 9; break;
	}
	for (x = startX; x < endX; x++) {													//		 Loop from beginning of x-quadrant to the end
		for (y = startY; y < endY; y++) {												//				Loop from beginning of y-quadrant to the end
			if (grid[x][y] == val) {													//					If the value at grid[x][y] equals val
				return true;															//						The number already exists in the 3 by 3 box, so return true
			}																			//					End If
		}																				//				End Loop
	}																					//		 End Loop
	return false;																		//		 Default return of false when the number is not found in the 3 by 3 box
}																						// End


/*************************************************************************************
* Function Title: FindNextSquareInPlay
*
* Summary: Find the next empty square in the grid array (square with value of 0)
*
* Inputs:  *x, *y
* Outputs:	1 (if the next square was found), or 0 (if it was not)
**************************************************************************************/
int Sudoku::findNextSquareInPlay(int *x, int *y)										// Psuedocode
{																						// Begin
	(*y)++;																				// Increment *y to move over one square
	for (; *x < 9; (*x)++){																//		Loop until end of column (*x == 9), starting at current value of *x
		for (; *y < 9; (*y)++) {														//			Loop until end of row	(*y == 9), starting at current value of *y
			if (fixed[*x][*y] == 0) {													//				If the value at grid[*x][*y] is 0
				return 1;																//					The next square in play was found, so return 1
			}																			//				End If
		}																				//			End Loop
		if (*y == 9) {																	//			If *y is 9
			*y = 0;																		//				*y is at the end of the row, so reset it to 0
		}																				//			End If
	}																					//		End Loop																			
	return 0;																			//		Default return of 0 if no "next square" is found
}																						// End

/*************************************************************************************
* Function Title: FindPrevSquareInPlay
*
* Summary: Find the next empty square in the grid array (square with value of 0)
*
* Inputs:  *x, *y
* Outputs:	1 (if the next square was found), or 0 (if it was not)
**************************************************************************************/
int Sudoku::findPrevSquareInPlay(int *x, int *y)										// Psuedocode
{																						// Begin
	(*y)--;																				// Decrement *y to go back one square
	for (; *x >= 0; (*x)--){																//		Loop until end of column (*x == 9), starting at current value of *x
		for (; *y >= 0; (*y)--) {														//			Loop until end of row	(*y == 9), starting at current value of *y
			if (fixed[*x][*y] == 0) {													//				If the value at grid[*x][*y] is 0
				return 1;																//					The next square in play was found, so return 1
			}																			//				End If
		}																				//			End Loop
		if (*y == -1) {																	//			If *y is -1
			*y = 8;																		//				*y is at the beginning of the row, so reset it to 9
		}																				//			End If
	}																					//		End Loop																			
	return 0;																			//		Default return of 0 if no "next square" is found
}																						// End

/*************************************************************************************
* Function Title: Solve
*
* Summary: Solve the randomly generated grid and print the results.

* Inputs: none
* Outputs:	1 (if successfully solved), or 0 (if not)
**************************************************************************************/
int Sudoku::solve()																		// Psuedocode
{																						// Begin
	int x = 0, y = -1, val = 1;															//		Declare and initialize variables to be used (y = -1 to offset for when findNextSquareInPlay() increments it)
	findNextSquareInPlay(&x, &y);														//		Find the first square in play
	first.x = x; first.y = y;															//		Set first position to equal the current position

	for (;;) {																			//		Loop until a return is executed
		if (isLegal(val, x, y)) {														//			If no violations
			grid[x][y] = val;															//				Place n at grid[x, y]
			val = 1;																	//				Set val to 1, set previous position to (x, y)
			if (!findNextSquareInPlay(&x, &y)) {										//				If next square does not exist (off grid)
				return 1;																//					The solve was successful, so return 1	
			}																			//				End If
		} else {																		//			Else 
			val++;																		//				Increase val by 1
			if (val > 9) {																//				If val is greater than 9
				grid[x][y] = 0;															//						Set the current square at grid[x][y] back to 0
				if (!findPrevSquareInPlay(&x, &y)) {									//						If previous location does not exist
					return 0;															//							The solve was unsuccessful, so return 0
				} else {																//						Else
					val = grid[x][y] + 1;												//							Set val to equal the now current square's value plus 1
				}																		//						End If
			}																			//				EndIf
		}																				//			EndIf
	}																					//		EndLoop
}																						//	End