#include "Sudoku.h"
#include <iostream> 
using namespace std;
/*************************************************************************************
* Function Title: Main
*
* Summary: Prompts the user to enter the number of squares to prepopulate in a Sudoku 
* puzzle, prints the respective grid, then prints the solved grid to the console.
*
* Inputs: none
* Outputs:	none
**************************************************************************************
* Pseudocode
*
* Begin
*	Declare variables to be used
*	Print program instructions
*	Get number of squares to prepopulate
*	Instantiate object of Sudoku class
*	If s.solve() does not return 0
*		Print "solved" message
*		Print the solved grid
*	Else
*		Print "unsolvable" message
*	End If
*	Keep results open
* End
**************************************************************************************/
int main()
{																// Begin
	int n;														//		Declare variables to be used
	cout << "Welcome to SudokuSolver!!" << endl;				//		Print program instructions
	cout << "Attempting to solve on your own may lead to brain malfunction, so let the computer solve it!" << endl;
	cout << "Enter number of squares to prepopulate: ";
	cin >> n;													//		Get number of squares to prepopulate
	Sudoku s(n);												//		Instantiate object of Sudoku class
	if (s.solve()) {											//		If s.solve() does not return 0
		cout << "Solved!" << endl;								//			Print "solved" message
		s.printGrid();											//			Print the solved grid
	}
	else {														//		Else
		cout << "Sorry, unsolvable..." << endl;					//			Print "unsolvable" message
	}															//		End If
	getchar(); getchar();										//		Keep results open
	return 0;		
}																// End