#pragma once
class Sudoku	{
	public:
		Sudoku (int start_num);
		int solve();
		void printGrid();
	private:
		bool inRow(int val, int y);
		bool inCol(int val, int x);
		bool inBox(int val, int x, int y);
		bool isLegal(int val, int x, int y){ return !inRow(val, y) && !inCol(val, x) && !inBox(val, x, y) && val <= 9;}

		int findNextSquareInPlay(int *x, int *y);
		int findPrevSquareInPlay(int *x, int *y);

		struct position { int x = 0, y= 0; } first;

		void initializeGrid();
		int grid[9][9];
		int fixed[9][9];
};

