#include "Quadra-Calc.h"

/***************************************************************************************
* Function Title: main
*
* Summary:  Checks that the command line arguments are entered correctly, determines the output stream to write to (either to the screen,
* or to an output file if one is provided), reads lines containing 3 integers representing a, b, and c from an input text file, and then calls 
* function "print_calculated_quadratic" to calculate and print the results.
*
* Inputs: argv, argc
* Outputs: None
****************************************************************************************
* Psuedocode
*
* Begin
*	Declare variables to be used
*	Check the number of command line arguments
*		If the number of arguments is not equal to 2 or 3
*			Print an error message and terminate the program
*		End If
*	Try to open the input file for reading
*		If there is an error 
*			Print an error message and terminate the program
*		End If
*	If the number of arguments is equal to 3
*		Try to open the output file for writing
*			If there is an error 
*				Print an error message and terminate the program
*			End If
*	Else	
*		Set the output stream to equal the standard output stream
*	End If	
*	Loop while the file hasn't ended
*		Scan for 3 integers and store to "a", "b", and "c"
*		Call "print_calculated_quadratic" to calculate the roots and print to the output stream
*	End Loop
*	Close both files
*	Print program execution success message
* End
****************************************************************************************/
int main (int argc, char* argv[])
{ 																								//	Begin
	FILE *input_fp, *output_fp;																	// 		Declare variables to be used
	int a, b, c;                                                                               
																								//		Check the number of command line arguments
	if (!(argc == 2 || argc == 3)){																//		If the number of arguments is not equal to 2 or 3
		printf ("Incorrect number of arguments:\nMust only include name of the input file"		//			Print an error message and terminate the program
				 " or name of input file and output file."); exit (-1);     						
	}        																					//		End If
																								//		Try to open the input file for reading
																								
	if ((input_fp = fopen(argv[1], "r"))== NULL){												//			If there is an error 
		printf ("Problem opening \"%s\"", argv[1]);	exit (1);									//				Print an error message and terminate the program
	}																							//			End If
	if (argc == 3){																				//		If the number of arguments is equal to 3
																								//			Try to open the output file for writing
			if ((output_fp = fopen(argv[2], "w"))== NULL){										//				If there is an error 
				printf ("Problem opening \"%s\"", argv[2]);	exit (2);							//					Print an error message and terminate the program
			}		                                                                            //				End If
	} else {                                                                                    //		Else	
		output_fp = stdout;                                                                     //			Set the output stream to equal the standard output stream
	}																							//		End If	
																											
	while (!feof(input_fp)){																	//		Loop while the file hasn't ended
		fscanf (input_fp, "%d %d %d", &a, &b, &c);												//			Scan for 3 integers and store to "a", "b", and "c"
		print_calculated_quadratic (a, b, c, output_fp);										//			Call "print_calculated_quadratic" to calculate the roots and print to the output stream
	}																							//		End Loop
																					            
	fclose(input_fp);	fclose(output_fp);														//		Close both files
	                                                                                            
	printf("\nProgram execution successful.");													//		Print program execution success message
	return 0;
} 																								//	End																		


/***************************************************************************************
* Function Title: print_calculated_quadratic
*
* Summary:  Calculates the roots for the equation "ax2 + bx + c = 0" using the quadratic formula, then prints to the provided
* output stream the a, b, and c integers followed by the roots or by "complex" if it is a complex number, with a tab in between each token.
*
* Inputs: a, b, c, output_stream
* Outputs: None
****************************************************************************************/
void print_calculated_quadratic (int a, int b, int c, FILE *output_stream)
{																								// 	Begin
	double x1, x2;																				// 		Declare variables to be used
						
	if ((b*b) - (4*a*c) < 0)	{																// 		If the number under the radical will be negative
		fprintf (output_stream, "%d\t%d\t%d\tcomplex\n", a, b, c);								// 			Print a, b, and c followed by the word "complex"
	} else {																					// 		Else
		x1 = (-b + sqrt(b*b - 4*a*c)) / (2*a);													// 			Set "x1" to equal the -b MINUS ... version of the quadratic formula
		x2 = (-b - sqrt(b*b - 4*a*c)) / (2*a);													// 			Set "x2" to equal the -b PLUS ... version of the quadratic formula
		fprintf (output_stream, "%d\t%d\t%d\t%.4f\t%.4f\n", a, b, c, x1, x2);					// 			Print a, b, and c followed by the x values
	}										
}																								// 	End

