#ifndef QUADRA_CALC_H
#define QUADRA_CALC_H
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Function Prototypes */
void print_calculated_quadratic (int a, int b, int c, FILE *output_stream);

#endif	