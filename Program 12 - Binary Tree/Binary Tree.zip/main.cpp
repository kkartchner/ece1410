#include "btree.h"
#include <iostream>
#include <fstream>

using namespace std;
/**********************************************************************************************
* Function Name: main
*
* Summary: Adds or deletes numbers to or from a binary tree based on command and int pairs read
* from provided input file, then prints each number in the binary tree to an output file with it's
* accompanying log base 10.
*
* Inputs: n (the number to delete from the binary tree)
* Outputs: none
***********************************************************************************************/
int main(int argc, char *argv[])
{																						// Begin
	ofstream output; ifstream input;													//		Variable declarations
	bTree tree;																			
	char command; short num;
																						//		Check for 3 commandline arguments
	if (argc != 3) {																	//		If there are not 3
		cout << "Commandline error: \nmust have input and output file name.";			//			Print error message
		return 1;																		//			Return 1
	}																					//		End If

	input.open(argv[1]);																//		Try to open the input file														
	if (!input.good()) {																//		If there is a problem
		cout << "Failure to open " << argv[1];											//			Print error message
		return 2;																		//			Return 2
	}																					//		End If

	cout << "Reading input file..." << endl;											//		Print reading input message
	while (!input.eof()){																//		Loop through input file
		input >> command >> num;														//			Read current line and store to command and num
		switch (command){																//			Add or delete num to or from the binary tree based on command's value
			case 'a': tree.addNumber(num); break;
			case 'd': tree.delNumber(num); break;
		}
	}																					//		End Loop

	output.open(argv[2]);																//		Try to open the output file
	if (!output.good()){																//		If there is a problem
		cout << "Failure to open " << argv[2];											//			Print error message
		return 3;																		//			Return 3
	}																					//		End If
																				
	tree.printToFile(&output);															//		Print the binary tree to the output file in ascending order

	cout << "Success!" << endl;															//		Print success message
	return 0;																			//		Default return of 0
}																						// End