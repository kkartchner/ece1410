#include "btree.h"
#include <cmath>
#include <iostream>

/* Function Definitions for Node */
Node::Node(short n) { number = n; left = nullptr; right = nullptr;}

short Node::getNumber() { return number; }
void Node::setNumber(short n) { number = n; }

Node * Node::getLeft() { return left; }
Node * Node::getRight() { return right; }

void Node::setLeft(Node * l) {	left = l; }
void Node::setRight(Node * r) {	right = r; }


/* Function Definitions for bTree*/
bTree::bTree() { root = nullptr; }

/**********************************************************************************************
* Function Name: addNumber
*
* Summary: Adds the provided number to the binary tree based on where it's value fits in the tree,
* as long as it isn't a duplicate of a number already in the tree
*
* Inputs: n (the number to add to the binary tree)
* Outputs: none
***********************************************************************************************/
void bTree::addNumber(short n)													// Psuedocode
{																				// Begin
	Node *m = new Node(n);														//		Create new node m
	if (m == nullptr) {std::cout << "Node creation failed."; return;}			//		Print error message if node fails to create
		
	Node *p = root;																//		Create temporary pointer �p� and point it to root
	if (p == nullptr) {															//		If p is null
		root = m;																//			Set root to the new node
	} else {																	//		Else
		for (;;) {																//			Loop forever
			if (m->getNumber() < p->getNumber()) {								//				If new node m's number is less than p
				if (p->getLeft() != nullptr) {									//					If left branch exists
					p = p->getLeft();											//						Take left branch
				} else {														//					Else
					p->setLeft(m);												//						Create left branch
					return;														//						Return
				}																//					End If
			} else if (m->getNumber() > p->getNumber()) {						//				Else If new node m's number is greater than p
				if (p->getRight() != nullptr) {									//					If right branch exists
					p = p->getRight();											//						Take right branch
				} else {														//					Else
					p->setRight(m);												//						Create right branch
					return;														//						Return
				}																//					EndIf
			} else {															//				Else (new node m's value is already in tree)
				delete (m);														//					Delete new node m
				return;															//					Return
			}																	//				EndIf
		}																		//			EndLoop					
	}																			//		End If
}																				// End

/**********************************************************************************************
* Function Name: delNumber
*
* Summary: Finds and properly deletes the node with number n based on how many children it has
*
* Inputs: n (the number to delete from the binary tree)
* Outputs: none
***********************************************************************************************/
void bTree::delNumber(short n)													// Psuedocode
{																				// Begin
	Node *cur = root, *prev = nullptr;											//		Variables in use
																				//		Find number position in tree:
	while (cur != nullptr) {													//			Loop while cur is not null
		if (n < cur->getNumber()) {												//				If number n is less than cur's number
			prev = cur;															//					Set prev to cur
			cur = cur->getLeft();												//					Set cur to cur's left child
		} else if (n > cur->getNumber()) {										//				Else If n is greater than cur's number
			prev = cur;															//					Set prev to cur
			cur = cur->getRight();												//					Set cur to cur's right child
		} else {																//				Else (cur and n are equal)
			break;																//					Break out of loop
		}																		//				End If
	}																			//			End Loop
																				//		End Find
	if (cur == nullptr) {														//		If cur is null after the search
		return;																	//			The number doesn't exist, so return out of function
	}																			//		End If
	
	if (cur->getLeft() == nullptr && cur->getRight() == nullptr) {				//		If cur has no children
		if (cur == root) {														//			If cur is the root
			root = nullptr;														//				Set root to nullptr
		} else {																//			Else
			if (cur->getNumber() > prev->getNumber()) {							//				If cur is on the right side of prev
				prev->setRight(nullptr);										//					Set prev's right pointer to nullptr
			} else {															//				Else
				prev->setLeft(nullptr);											//					Set prev's left pointer to nullptr
			}																	//				End If
		}																		//			End If
	} 
	else if (cur->getLeft() != nullptr && cur->getRight() == nullptr) {			//		Else If cur only has a left child
		if (cur == root) {														//			If cur is the root
			root = cur->getLeft();												//				Change root to cur's left child
		} else {																//			Else
			if (cur->getNumber() > prev->getNumber()) {							//				If cur is on the right side of prev
				prev->setRight(cur->getLeft());									//					Set prev's right to point to cur's left
			} else {															//				Else
				prev->setLeft(cur->getLeft());									//					Set prev's left to point to cur's left
			}																	//				End If
		}																		//			End If
	} 
	else if (cur->getLeft() == nullptr && cur->getRight() != nullptr) {			//		Else If cur has only right child
		if (cur == root) {														//			If cur is the root
			root = cur->getRight();												//				Set root to cur's right child
		} else {																//			Else
			if (cur->getNumber() > prev->getNumber()) {							//				If cur is on the right side of prev
				prev->setRight(cur->getRight());								//					Set prev's right to cur's right
			} else {															//				Else
				prev->setLeft(cur->getRight());									//					Set prev's left to cur's right
			}																	//				End If
		}																		//			End If
	}
	else if (cur->getLeft() != nullptr && cur->getRight() != nullptr) { 		//		Else If cur has both left and right child
		Node *subRoot = prev = cur;												//			Set subRoot and prev to cur
		cur = cur->getRight();													//			Set cur to it's right child
		bool wentLeft = false;													//			Set wentLeft to false
		while (cur->getLeft() != nullptr) {										//			Loop until current node no longer has a left child																//	
			prev = cur;															//				Set prev to cur
			cur = cur->getLeft();												//				Set cur to cur's left child
			wentLeft = true;													//				Set wentLeft to true
		}																		//			End Loop
		subRoot->setNumber(cur->getNumber());									//			Set subRoot's to cur's number
		if (wentLeft) {															//			If wentLeft is true
			prev->setLeft(nullptr);												//				Set prev's left pointer to nullptr
		} else {																//			Else
			prev->setRight(nullptr);											//				Set prev's right pointer to nullptr
		}																		//			End If
	}																			//		End If

	delete (cur);																//		Delete cur
}

/**********************************************************************************************
* Function Name: printToFile
*
* Summary: Prints the binary tree to provided file from least to greatest by calling a recursive 
* function that prints each subtree starting with root
*
* Inputs: os (the file to print to)
* Outputs: none
***********************************************************************************************/
void bTree::printToFile(std::ofstream * os)												// Psuedocode
{																						// Begin
	os->precision(5);																	//		 Set precision to 5
	std::cout << "Printing to output file..." << std::endl;								//		 Print outpout message
	printSubTree(root, os);																//		 Print subtrees starting with root
}																						// End

/**********************************************************************************************
* Function Name: printSubTree
*
* Summary: Recursively prints each node in a subtree
*
* Inputs: n (starting node to print), os (file to print to)
* Outputs: none
***********************************************************************************************/
void bTree::printSubTree(Node *n, std::ofstream * os)									// Psuedocode
{																						// Begin
	if (n) {																			//		If n is not null
		printSubTree(n->getLeft(), os);													//			Print n's left subtree
		*os << n->getNumber() << "\t" << log10((double)n->getNumber()) << std::endl;	//			Print n to file
		printSubTree(n->getRight(), os);												//			Print n's right subtree
	}																					//		End if
}																						// End

/**********************************************************************************************
* Function Name: delNumber																		
*
* Summary: Recursively deletes each node in a subtree
*
* Inputs: n (starting node to delete)
* Outputs: none
***********************************************************************************************/
void bTree::deleteSubTree(Node *n)														// Psuedocode
{																						// Begin
	if (n) {																			//		If n is not null
		deleteSubTree(n->getLeft());													//			Delete n's left subtree
		deleteSubTree(n->getRight());													//			Delete n's right subtree
		std::cout << "Deleting " << n->getNumber() << "..." << std::endl;				//			Print delete message
		delete (n);																		//			Delete n
	}																					//		End If
}																						// End

/* Desconstructor */
bTree::~bTree() {
	deleteSubTree(root); // Recursively delete each node in the binary tree on program termination
}