#ifndef BTREE_H
#define BTREE_H
#include <fstream>

class Node
{
public:
	Node(short n);
	short getNumber();
	void setNumber(short n);
	Node *getLeft(); Node *getRight();
	void setLeft(Node * l); void setRight(Node * r);
private:
	short number;
	Node *left, *right;
};

class bTree
{
public:
	bTree();
	void addNumber(short n);
	void delNumber(short n);
	void printToFile(std::ofstream * os);
	void printSubTree(Node * n, std::ofstream * os);
	void deleteSubTree(Node * n);
	~bTree();
private:
	Node *root;
};
#endif
