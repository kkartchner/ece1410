#ifndef IOSTREAM
#define IOSTREAM
#include <iostream>
#endif

#ifndef BUBBLE_H
#define BUBBLE_H
template<class T>
class Bubble
{

public:
	Bubble(T *, int);
	void print(T *, int);
};

template <class T>
Bubble<T>::Bubble(T* array, int size) {
	bool swapped = true; 
	while (swapped == true) {					// Loop until elements no longer are swapped
		swapped = false;
		for (int i = 1; i < size; i++)
		{
			if (array[i - 1] > array[i]) {	
				T temp = array[i];					
				array[i] = array[i - 1];
				array[i - 1] = temp;
				swapped = true;
			} 						
		}
	}											// End Loop
}

template <class T>
void Bubble<T>::print(T *array, int size) {
	for (int i = 0; i < size; i++) {
		std::cout << array[i] << " ";
	}
}

#endif
