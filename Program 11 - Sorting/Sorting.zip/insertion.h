#ifndef IOSTREAM
#define IOSTREAM
#include <iostream>
#endif

#ifndef INSERTION_H
#define INSERTION_H
template<class T>
class Insertion
{

public:
	Insertion(T *, int);
	void print(T *, int);
};

template <class T>
Insertion<T>::Insertion(T* array, int size) {
	int i, j;
	for (i = 1; i < size; i++){
		for (j = i; j > 0 && array[j - 1] > array[j]; j--)
		{
			T temp = array[j];
			array[j] = array[j - 1];
			array[j - 1] = temp;
		}
	}
}

template <class T>
void Insertion<T>::print(T *array, int size) {
	for (int i = 0; i < size; i++) {
		std::cout << array[i] << " ";
	}
}
#endif
