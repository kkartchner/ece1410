#ifndef QUADRA_CALC_H
#define QUADRA_CALC_H
#include <iostream>
#include <fstream>
#include <math.h>

/* Function Prototypes */
void print_calculated_quadratic (int a, int b, int c, std::ostream& output_stream);
#endif	