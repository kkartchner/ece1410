#include "Quadra-Calc++.h"

/***************************************************************************************
* Function Title: main
*
* Summary:  Checks that the command line arguments are entered correctly, determines the outputf stream to write to (either to the screen,
* or to an output file if one is provided), reads lines containing 3 integers representing a, b, and c from an inputf text file, and then calls 
* function "print_calculated_quadratic" to calculate and print the results.
*
* inputs: argv, argc
* outputs: None
****************************************************************************************
* Psuedocode
*
*	Begin
*		Declare variables to be used																
*		Check the number of command line arguments
*			If the number of arguments is not equal to 2 or 3
*				Print an error message and terminate the program
*			End If
*		Try to open the input file for reading															
*			If there is an error 
*				Print an error message and terminate the program
*			End If
*		If the number of arguments is equal to 3
*			Try to open the output file for writing
*				If there is an error 
*					Print an error message and terminate the program
*				End If
*			Loop while the input file hasn't ended
*				Scan for 3 integers and store to "a", "b", and "c"
*				Call "print_calculated_quadratic" to calculate the roots and print to the output file
*			End Loop
*		Else
*			Loop while the input file hasn't ended
*				Scan for 3 integers and store to "a", "b", and "c"
*				Call "print_calculated_quadratic" to calculate the roots and print to the screen
*			End Loop
*		End If
*		Close both files                                                                         
*		Print program execution success message
*	End	
****************************************************************************************/
using namespace std;

int main (int argc, char* argv[])
{ 																								//	Begin
	ifstream inputf; ofstream outputf;															// 		Declare variables to be used																
	int a, b, c;                                                                               
																								//		Check the number of command line arguments
	if (!(argc == 2 || argc == 3)){																//		If the number of arguments is not equal to 2 or 3
		printf ("Incorrect number of arguments:\nMust only include name of the input file"		//			Print an error message and terminate the program
				 " or name of input file and output file."); exit (-1);     						
	}        																					//		End If
	inputf.open(argv[1], ios::in);																//		Try to open the input file for reading																							
	if (!inputf.is_open()){																		//			If there is an error 
		printf ("Problem opening \"%s\"", argv[1]);	exit (1);									//				Print an error message and terminate the program
	}																							//			End If
	if (argc == 3){																				//		If the number of arguments is equal to 3
		outputf.open(argv[2], ios::out);														//			Try to open the output file for writing
		if (!outputf.is_open()){																//				If there is an error 
			printf ("Problem opening \"%s\"", argv[2]);	exit (2);								//					Print an error message and terminate the program
		}		                                                                            	//				End If
		while (inputf.good()){																	//			Loop while the input file hasn't ended
			inputf >> a >> b >> c;																//				Scan for 3 integers and store to "a", "b", and "c"
			print_calculated_quadratic (a, b, c, outputf);										//				Call "print_calculated_quadratic" to calculate the roots and print to the output file
		}																						//			End Loop
	} else {																					//		Else
		while (inputf.good()){																	//			Loop while the input file hasn't ended
			inputf >> a >> b >> c;																//				Scan for 3 integers and store to "a", "b", and "c"
			print_calculated_quadratic (a, b, c, cout);											//				Call "print_calculated_quadratic" to calculate the roots and print to the output stream
		}																						//			End Loop
	}																				           	//		End If
	inputf.close();	outputf.close();															//		Close both files                                                                         
	printf("\nProgram execution successful.");													//		Print program execution success message
	return 0;
} 																								//	End																		


/***************************************************************************************
* Function Title: print_calculated_quadratic
*
* Summary:  Calculates the roots for the equation "ax2 + bx + c = 0" using the quadratic formula, then prints to the provided
* output stream the a, b, and c integers followed by the roots or by "complex" if it is a complex number, with a tab in between each token.
*
* inputs: a, b, c, output
* outputs: None
****************************************************************************************/
void print_calculated_quadratic (int a, int b, int c, ostream& output)
{																								// 	Begin
	double x1, x2;																				// 		Declare variables to be used
	output << fixed; output.precision(4);														// 		Initialize output stream
	if ((b*b) - (4*a*c) < 0)	{																// 		If the number under the radical will be negative
		output << a << "\t" << b << "\t" << c << "\tcomplex" << endl;							// 			Print a, b, and c followed by the word "complex"
	} else {																					// 		Else
		x1 = (-b + sqrt(b*b - 4*a*c)) / (2*a);													// 			Set "x1" to equal the -b MINUS ... version of the quadratic formula
		x2 = (-b - sqrt(b*b - 4*a*c)) / (2*a);													// 			Set "x2" to equal the -b PLUS ... version of the quadratic formula
		output << a << "\t" << b << "\t" << c << "\t" << x1 << "\t" << x2 << "\n" << endl;		// 			Print a, b, and c followed by the x values
	}																							// 		End If
}																								// End

